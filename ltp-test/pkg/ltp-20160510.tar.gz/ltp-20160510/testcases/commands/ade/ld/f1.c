
void f1(void)
{
	int i = 69;
	i = i;
	return;
}
