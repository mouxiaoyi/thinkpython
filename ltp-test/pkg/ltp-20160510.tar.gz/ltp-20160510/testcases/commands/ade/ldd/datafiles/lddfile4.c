#include <stdio.h>
void file4(void)
{
	printf("Control in function %s\n", __func__);
}
